package com.yunbian.adsscoring.scoring.service.impl;

import com.yunbian.adsscoring.campaign.dto.CampaignMetricsMatrixItem;
import com.yunbian.adsscoring.campaign.mapper.CampaignMetricsMatrixMapper;
import com.yunbian.adsscoring.scoring.dto.CampaignRankingPreviewResponse;
import com.yunbian.adsscoring.scoring.dto.CampaignWeightedRankingPreviewResponse;
import com.yunbian.adsscoring.scoring.enums.ScoringEntityLevel;
import com.yunbian.adsscoring.scoring.enums.ScoringMetricKey;
import com.yunbian.adsscoring.scoring.enums.ScoringRuleType;
import com.yunbian.adsscoring.scoring.request.ScoringLevelConfigRequest;
import com.yunbian.adsscoring.scoring.request.ScoringMetricConfigRequest;
import com.yunbian.adsscoring.scoring.request.ScoringSchemeCreateRequest;
import com.yunbian.adsscoring.scoring.service.ScoringPreviewService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class ScoringPreviewServiceImpl implements ScoringPreviewService {

    private static final BigDecimal ONE_HUNDRED = new BigDecimal("100");
    private static final BigDecimal ZERO = BigDecimal.ZERO;

    @Resource
    private CampaignMetricsMatrixMapper campaignMetricsMatrixMapper;

    @Override
    public CampaignRankingPreviewResponse previewCampaignRanking(
            Long sid,
            LocalDate logDate,
            ScoringMetricKey metricKey,
            Integer effectDays
    ) {
        List<CampaignMetricsMatrixItem> sourceRows =
                campaignMetricsMatrixMapper.selectAllMetricsMatrixBySidAndLogDate(sid, logDate);

        List<MetricCandidate> candidates = buildMetricCandidates(sourceRows, metricKey, effectDays);
        sortMetricCandidates(candidates, metricKey);

        List<CampaignRankingPreviewResponse.CampaignRankingRow> rankingRows = new ArrayList<>();
        int comparisonCount = candidates.size();

        for (int i = 0; i < candidates.size(); i++) {
            MetricCandidate candidate = candidates.get(i);

            CampaignRankingPreviewResponse.CampaignRankingRow row =
                    new CampaignRankingPreviewResponse.CampaignRankingRow();
            row.setCampaignId(candidate.getCampaignId());
            row.setCampaignName(candidate.getCampaignName());
            row.setMetricValue(candidate.getMetricValue());
            row.setRank(i + 1);
            row.setScore(buildRankingScore(i + 1, comparisonCount));

            rankingRows.add(row);
        }

        CampaignRankingPreviewResponse response = new CampaignRankingPreviewResponse();
        response.setSid(sid);
        response.setLogDate(logDate);
        response.setEntityLevel("campaign");
        response.setRuleType("ranking");
        response.setMetricKey(metricKey.getCode());
        response.setMetricName(metricKey.getName());
        response.setMetricDirection(metricKey.getDirection());
        response.setEffectDays(effectDays);
        response.setRawRowCount(sourceRows.size());
        response.setComparisonCount(comparisonCount);
        response.setExcludedNullCount(sourceRows.size() - comparisonCount);
        response.setRows(rankingRows);
        return response;
    }

    @Override
    public CampaignWeightedRankingPreviewResponse previewCampaignWeightedRanking(
            Long sid,
            LocalDate logDate,
            Integer effectDays,
            ScoringSchemeCreateRequest request
    ) {
        List<CampaignMetricsMatrixItem> sourceRows =
                campaignMetricsMatrixMapper.selectAllMetricsMatrixBySidAndLogDate(sid, logDate);

        ScoringLevelConfigRequest campaignLevelConfig = request.getLevelConfigs().stream()
                .filter(level -> ScoringEntityLevel.CAMPAIGN.getCode().equals(level.getEntityLevel()))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("campaign level config is required"));

        List<RankingMetricSpec> rankingMetricSpecs = campaignLevelConfig.getMetricConfigs().stream()
                .filter(metric -> Boolean.TRUE.equals(metric.getEnabled()))
                .filter(metric -> ScoringRuleType.RANKING.getCode().equals(metric.getRuleType()))
                .map(this::buildRankingMetricSpec)
                .toList();

        List<CampaignWeightedRankingPreviewResponse.MetricSummary> metricSummaries = new ArrayList<>();
        Map<Long, WeightedRowAccumulator> rowAccumulatorMap = new LinkedHashMap<>();

        for (RankingMetricSpec metricSpec : rankingMetricSpecs) {
            List<MetricCandidate> candidates = buildMetricCandidates(sourceRows, metricSpec.getMetricKey(), effectDays);
            sortMetricCandidates(candidates, metricSpec.getMetricKey());

            int comparisonCount = candidates.size();
            int excludedNullCount = sourceRows.size() - comparisonCount;
            boolean usedInAggregation = comparisonCount > 0 && metricSpec.getWeight().compareTo(ZERO) > 0;

            CampaignWeightedRankingPreviewResponse.MetricSummary metricSummary =
                    new CampaignWeightedRankingPreviewResponse.MetricSummary();
            metricSummary.setMetricKey(metricSpec.getMetricKey().getCode());
            metricSummary.setMetricName(metricSpec.getMetricKey().getName());
            metricSummary.setWeight(metricSpec.getWeight());
            metricSummary.setComparisonCount(comparisonCount);
            metricSummary.setExcludedNullCount(excludedNullCount);
            metricSummary.setUsedInAggregation(usedInAggregation);
            metricSummaries.add(metricSummary);

            if (!usedInAggregation) {
                continue;
            }

            for (int i = 0; i < candidates.size(); i++) {
                MetricCandidate candidate = candidates.get(i);
                int rank = i + 1;
                BigDecimal score = buildRankingScore(rank, comparisonCount);
                BigDecimal weightedScore = score.multiply(metricSpec.getWeight());

                WeightedRowAccumulator accumulator = rowAccumulatorMap.computeIfAbsent(
                        candidate.getCampaignId(),
                        key -> {
                            WeightedRowAccumulator value = new WeightedRowAccumulator();
                            value.setCampaignId(candidate.getCampaignId());
                            value.setCampaignName(candidate.getCampaignName());
                            value.setWeightedScoreSum(ZERO);
                            value.setParticipatingWeightSum(ZERO);
                            value.setMetricContributions(new ArrayList<>());
                            return value;
                        }
                );

                accumulator.setCampaignName(candidate.getCampaignName());
                accumulator.setWeightedScoreSum(accumulator.getWeightedScoreSum().add(weightedScore));
                accumulator.setParticipatingWeightSum(accumulator.getParticipatingWeightSum().add(metricSpec.getWeight()));

                CampaignWeightedRankingPreviewResponse.MetricContribution contribution =
                        new CampaignWeightedRankingPreviewResponse.MetricContribution();
                contribution.setMetricKey(metricSpec.getMetricKey().getCode());
                contribution.setMetricName(metricSpec.getMetricKey().getName());
                contribution.setMetricValue(candidate.getMetricValue());
                contribution.setRank(rank);
                contribution.setScore(score);
                contribution.setWeight(metricSpec.getWeight());
                contribution.setWeightedScore(weightedScore.setScale(4, RoundingMode.HALF_UP));

                accumulator.getMetricContributions().add(contribution);
            }
        }

        List<CampaignWeightedRankingPreviewResponse.CampaignWeightedRankingRow> rows = rowAccumulatorMap.values().stream()
                .map(this::buildWeightedRankingRow)
                .sorted(
                        Comparator.comparing(
                                        CampaignWeightedRankingPreviewResponse.CampaignWeightedRankingRow::getTotalScore,
                                        Comparator.nullsLast(BigDecimal::compareTo)
                                )
                                .reversed()
                                .thenComparing(
                                        CampaignWeightedRankingPreviewResponse.CampaignWeightedRankingRow::getCampaignId,
                                        Comparator.nullsLast(Long::compareTo)
                                )
                )
                .toList();

        int usedMetricCount = (int) metricSummaries.stream()
                .filter(summary -> Boolean.TRUE.equals(summary.getUsedInAggregation()))
                .count();

        CampaignWeightedRankingPreviewResponse response = new CampaignWeightedRankingPreviewResponse();
        response.setSid(sid);
        response.setLogDate(logDate);
        response.setEntityLevel(ScoringEntityLevel.CAMPAIGN.getCode());
        response.setRuleType(ScoringRuleType.RANKING.getCode());
        response.setEffectDays(effectDays);
        response.setRawRowCount(sourceRows.size());
        response.setEnabledRankingMetricCount(rankingMetricSpecs.size());
        response.setUsedMetricCount(usedMetricCount);
        response.setSkippedMetricCount(rankingMetricSpecs.size() - usedMetricCount);
        response.setMetricSummaries(metricSummaries);
        response.setRows(rows);
        return response;
    }

    private RankingMetricSpec buildRankingMetricSpec(ScoringMetricConfigRequest metricConfig) {
        RankingMetricSpec metricSpec = new RankingMetricSpec();
        metricSpec.setMetricKey(
                ScoringMetricKey.fromCode(metricConfig.getMetricKey())
        );
        metricSpec.setWeight(metricConfig.getWeight());
        return metricSpec;
    }

    private CampaignWeightedRankingPreviewResponse.CampaignWeightedRankingRow buildWeightedRankingRow(
            WeightedRowAccumulator accumulator
    ) {
        CampaignWeightedRankingPreviewResponse.CampaignWeightedRankingRow row =
                new CampaignWeightedRankingPreviewResponse.CampaignWeightedRankingRow();
        row.setCampaignId(accumulator.getCampaignId());
        row.setCampaignName(accumulator.getCampaignName());
        row.setParticipatingMetricCount(accumulator.getMetricContributions().size());
        row.setParticipatingWeightSum(accumulator.getParticipatingWeightSum().setScale(4, RoundingMode.HALF_UP));

        BigDecimal totalScore = null;
        if (accumulator.getParticipatingWeightSum().compareTo(ZERO) > 0) {
            totalScore = accumulator.getWeightedScoreSum()
                    .divide(accumulator.getParticipatingWeightSum(), 4, RoundingMode.HALF_UP);
        }
        row.setTotalScore(totalScore);
        row.setMetricContributions(accumulator.getMetricContributions());
        return row;
    }

    private List<MetricCandidate> buildMetricCandidates(
            List<CampaignMetricsMatrixItem> sourceRows,
            ScoringMetricKey metricKey,
            Integer effectDays
    ) {
        List<MetricCandidate> candidates = new ArrayList<>();
        for (CampaignMetricsMatrixItem item : sourceRows) {
            BigDecimal metricValue = extractMetricValue(item, metricKey, effectDays);
            if (metricValue == null) {
                continue;
            }

            MetricCandidate candidate = new MetricCandidate();
            candidate.setCampaignId(item.getCampaignId());
            candidate.setCampaignName(item.getCampaignName());
            candidate.setMetricValue(metricValue);
            candidates.add(candidate);
        }
        return candidates;
    }

    private void sortMetricCandidates(List<MetricCandidate> candidates, ScoringMetricKey metricKey) {
        Comparator<BigDecimal> metricValueComparator = metricKey.isHigherBetter()
                ? (left, right) -> right.compareTo(left)
                : BigDecimal::compareTo;

        candidates.sort(
                Comparator.comparing(MetricCandidate::getMetricValue, metricValueComparator)
                        .thenComparing(MetricCandidate::getCampaignId, Comparator.nullsLast(Long::compareTo))
        );
    }

    private BigDecimal buildRankingScore(int rank, int comparisonCount) {
        if (comparisonCount <= 0) {
            return null;
        }
        if (comparisonCount == 1) {
            return ONE_HUNDRED.setScale(4, RoundingMode.HALF_UP);
        }

        BigDecimal numerator = BigDecimal.valueOf(comparisonCount - rank);
        BigDecimal denominator = BigDecimal.valueOf(comparisonCount - 1);

        return numerator
                .multiply(ONE_HUNDRED)
                .divide(denominator, 4, RoundingMode.HALF_UP);
    }

    private BigDecimal extractMetricValue(
            CampaignMetricsMatrixItem item,
            ScoringMetricKey metricKey,
            Integer effectDays
    ) {
        return switch (effectDays) {
            case 1 -> extract1dMetricValue(item, metricKey);
            case 3 -> extract3dMetricValue(item, metricKey);
            case 7 -> extract7dMetricValue(item, metricKey);
            default -> null;
        };
    }

    private BigDecimal extract1dMetricValue(CampaignMetricsMatrixItem item, ScoringMetricKey metricKey) {
        return switch (metricKey) {
            case ROI -> item.getRoi1d();
            case CVR -> item.getCvr1d();
            case CPC -> item.getEcpc1d();
            case CART_COST -> item.getCartCost1d();
            case DEAL_NEW_CUSTOMER_RATIO -> item.getDealNewCustomerRatio1d();
            case NEW_CUSTOMER_RATIO -> item.getNewCustomerRatio1d();
            case DIRECT_DEAL_RATIO -> item.getDirectDealRatio1d();
        };
    }

    private BigDecimal extract3dMetricValue(CampaignMetricsMatrixItem item, ScoringMetricKey metricKey) {
        return switch (metricKey) {
            case ROI -> item.getRoi3d();
            case CVR -> item.getCvr3d();
            case CPC -> item.getEcpc3d();
            case CART_COST -> item.getCartCost3d();
            case DEAL_NEW_CUSTOMER_RATIO -> item.getDealNewCustomerRatio3d();
            case NEW_CUSTOMER_RATIO -> item.getNewCustomerRatio3d();
            case DIRECT_DEAL_RATIO -> item.getDirectDealRatio3d();
        };
    }

    private BigDecimal extract7dMetricValue(CampaignMetricsMatrixItem item, ScoringMetricKey metricKey) {
        return switch (metricKey) {
            case ROI -> item.getRoi7d();
            case CVR -> item.getCvr7d();
            case CPC -> item.getEcpc7d();
            case CART_COST -> item.getCartCost7d();
            case DEAL_NEW_CUSTOMER_RATIO -> item.getDealNewCustomerRatio7d();
            case NEW_CUSTOMER_RATIO -> item.getNewCustomerRatio7d();
            case DIRECT_DEAL_RATIO -> item.getDirectDealRatio7d();
        };
    }

    private static class RankingMetricSpec {

        private ScoringMetricKey metricKey;
        private BigDecimal weight;

        public ScoringMetricKey getMetricKey() {
            return metricKey;
        }

        public void setMetricKey(ScoringMetricKey metricKey) {
            this.metricKey = metricKey;
        }

        public BigDecimal getWeight() {
            return weight;
        }

        public void setWeight(BigDecimal weight) {
            this.weight = weight;
        }
    }

    private static class MetricCandidate {

        private Long campaignId;
        private String campaignName;
        private BigDecimal metricValue;

        public Long getCampaignId() {
            return campaignId;
        }

        public void setCampaignId(Long campaignId) {
            this.campaignId = campaignId;
        }

        public String getCampaignName() {
            return campaignName;
        }

        public void setCampaignName(String campaignName) {
            this.campaignName = campaignName;
        }

        public BigDecimal getMetricValue() {
            return metricValue;
        }

        public void setMetricValue(BigDecimal metricValue) {
            this.metricValue = metricValue;
        }
    }

    private static class WeightedRowAccumulator {

        private Long campaignId;
        private String campaignName;
        private BigDecimal weightedScoreSum;
        private BigDecimal participatingWeightSum;
        private List<CampaignWeightedRankingPreviewResponse.MetricContribution> metricContributions;

        public Long getCampaignId() {
            return campaignId;
        }

        public void setCampaignId(Long campaignId) {
            this.campaignId = campaignId;
        }

        public String getCampaignName() {
            return campaignName;
        }

        public void setCampaignName(String campaignName) {
            this.campaignName = campaignName;
        }

        public BigDecimal getWeightedScoreSum() {
            return weightedScoreSum;
        }

        public void setWeightedScoreSum(BigDecimal weightedScoreSum) {
            this.weightedScoreSum = weightedScoreSum;
        }

        public BigDecimal getParticipatingWeightSum() {
            return participatingWeightSum;
        }

        public void setParticipatingWeightSum(BigDecimal participatingWeightSum) {
            this.participatingWeightSum = participatingWeightSum;
        }

        public List<CampaignWeightedRankingPreviewResponse.MetricContribution> getMetricContributions() {
            return metricContributions;
        }

        public void setMetricContributions(
                List<CampaignWeightedRankingPreviewResponse.MetricContribution> metricContributions
        ) {
            this.metricContributions = metricContributions;
        }
    }
}